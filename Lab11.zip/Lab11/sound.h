#include <stdio.h>
#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"


void dac_init(uint16_t initialData);
void DAC_Out(uint16_t code);
