#include <stdint.h>
#include <stdio.h>
#include "../inc/tm4c123gh6pm.h"

void notes_Init(void);
void Timer0A_Init(void);
