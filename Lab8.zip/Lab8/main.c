#include <stdint.h>
#include <stdio.h>
#include "../inc/tm4c123gh6pm.h"
#include "PLL.h"
#include "ST7735.h"
#include "sound.h"
#include "music.h"
#include "input.h"

void DisableInterrupts(void);
void EnableInterrupts(void); 
void DelayWait10ms(uint32_t n);

int main(void){
  PLL_Init(Bus50MHz);                   // 80 MHz
	ST7735_InitR(INITR_REDTAB);
  ST7735_FillScreen(ST7735_BLACK);  // set screen to black
	ST7735_SetTextColor(ST7735_WHITE);
	dac_init(0);
	Timer0A_Init();
	input_Init();
	notes_Init();
	while(1){
		DelayWait10ms(10);
	}
}
