#include <stdint.h>
#include <stdio.h>
#include "../inc/tm4c123gh6pm.h"

void input_Init(void);
void static writecommand(uint8_t addr, uint8_t cmd);
int static readInput(void);



