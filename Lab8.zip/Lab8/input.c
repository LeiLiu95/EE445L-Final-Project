#include "input.h"
#include "LED.h"
#include "music.h"
#include "sound.h"

void input_Init(){
	SYSCTL_RCGCGPIO_R |= 0x00000010; // (a) activate clock for port E
  GPIO_PORTE_DIR_R &= ~0x0F;    // (c) make PB0-3 in (built-in button)
  GPIO_PORTE_AFSEL_R &= ~0x0F;  //     disable alt funct on PE0-3
  GPIO_PORTE_DEN_R |= 0x0F;     //     enable digital I/O on PE0-3  
  GPIO_PORTE_PCTL_R &= ~0x0000FFFF; // configure PE0-3 as GPIO
  GPIO_PORTE_AMSEL_R = 0;       //     disable analog functionality on PE
  //GPIO_PORTB_PUR_R |= 0x10;     //     enable weak pull-up on PF4
  GPIO_PORTE_IS_R &= ~0x0F;     // (d) PE0-3 is edge-sensitive
  GPIO_PORTE_IBE_R &= ~0x0F;    //     PE0-3 is not both edges
  GPIO_PORTE_IEV_R &= ~0x0F;    //     PE0-3 falling edge event
  GPIO_PORTE_ICR_R = 0x0F;      // (e) clear flag0-3
  GPIO_PORTE_IM_R |= 0x0F;      // (f) arm interrupt ** No IME bit as mentioned in Book ***
  NVIC_PRI7_R = (NVIC_PRI7_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  NVIC_EN0_R = 0x10;      // (h) enable interrupt 1 (PortF) in NVIC
	
	SYSCTL_RCGCGPIO_R |= 0x00000002; // (a) activate clock for port B
  GPIO_PORTB_DIR_R &= ~0xF0;    // (c) make PB4-7 in (built-in button)
  GPIO_PORTB_AFSEL_R &= ~0xF0;  //     disable alt funct on PB4-7
  GPIO_PORTB_DEN_R |= 0xF0;     //     enable digital I/O on PB4-7  
  GPIO_PORTB_PCTL_R &= ~0xFFFF0000; // configure PB4-7 as GPIO
  GPIO_PORTB_AMSEL_R = 0;       //     disable analog functionality on PB
  //GPIO_PORTB_PUR_R |= 0x10;     //     enable weak pull-up on PF4
  //GPIO_PORTB_IS_R &= ~0xF0;     // (d) PB4-7 is edge-sensitive
  //GPIO_PORTB_IBE_R &= ~0xF0;    //     PB4-7 is not both edges
  //GPIO_PORTB_IEV_R &= ~0xF0;    //     PB4-7 falling edge event
  GPIO_PORTB_ICR_R = 0xF0;      // (e) clear flag 4-7
  GPIO_PORTB_IM_R |= 0xF0;      // (f) arm interrupt *** No IME bit as mentioned in Book ***
  NVIC_PRI7_R = (NVIC_PRI7_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  NVIC_EN0_R = 0x02;      // (h) enable interrupt 1 (PortB) in NVIC
}

void GPIOPortE_Handler(void){
  GPIO_PORTF_ICR_R = 0x10;      // acknowledge flag4
}

void GPIOPortB_Handler(void){
  GPIO_PORTF_ICR_R = 0x10;      // acknowledge flag4
}

int current_Input(void){
	return 0;								//return what note should be played
}

