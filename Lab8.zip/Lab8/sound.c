#include "sound.h"
#include "LED.h"
#include "music.h"
#include "input.h"

void dac_init(uint16_t initialData) {
	SYSCTL_RCGCSSI_R |= 0x01;
	SYSCTL_RCGCGPIO_R |= 0x01;
	while((SYSCTL_PRGPIO_R & 0x01) == 0){};
	GPIO_PORTD_AFSEL_R |= 0x2C;
	GPIO_PORTD_DEN_R |= 0x2C;
	GPIO_PORTD_PCTL_R = (GPIO_PORTA_PCTL_R & 0xFF0F00FF) + 0x00202200;
	GPIO_PORTD_AMSEL_R = 0;
	SSI1_CR1_R = 0x0;
	SSI1_CPSR_R = 0x02;
	SSI1_CR0_R &= ~(0x0000FFF0);
	SSI1_CR0_R |= 0x0F;
	SSI1_DR_R = initialData;
	SSI1_CR1_R |= 0x02;
}

void DAC_Out(uint16_t code) {
	while((SSI0_SR_R & 0x02) == 0){};
	SSI1_DR_R = code;
}
